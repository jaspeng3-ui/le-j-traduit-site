# Le-J traduit — extension (Chrome / Edge) · v0.3

OCR (Tesseract **ou** IA vision) → traduction (MyMemory **ou** DeepL) → audio →
**explications & rōmaji par IA** → vocabulaire, **flashcards** et **quiz**.
Forme de bulle réglable. Le moteur OCR local est embarqué (fonctionne hors-ligne).

---

## ✅ Nouveautés de cette version
- **Correctif OCR** : l'erreur « importScripts … worker.min.js failed to load » est résolue
  (`workerBlobURL:false` — le worker se charge en direct, ce que Manifest V3 impose).
- **DeepL** en moteur de traduction principal (qualité nettement meilleure).
- **IA OpenAI ou Claude** pour : explications, nuances, vocabulaire, **rōmaji complet**, et
  surtout **OCR vision** — bien plus fiable sur le manga que Tesseract.
- **Rōmaji automatique** : lecture kana instantanée intégrée + lecture complète (kanji
  compris) via l'IA.
- **Flashcards** et **quiz** générés depuis votre vocabulaire enregistré.
- **Forme de la bulle** réglable (arrondi / rectangle / pilule / ovale) via le bouton ◇ sur la bulle.

---

## 🟢 Activation
1. Décompressez le dossier.
2. Chrome → `chrome://extensions` (Edge → `edge://extensions`).
3. **Mode développeur** activé.
4. **« Charger l'extension non empaquetée »** → dossier **`le-j-traduit-pro`**.
5. Épinglez l'icône **LJ** (🧩 → 📌).

> Si vous mettiez à jour depuis la v0.2 : sur la carte de l'extension, cliquez **↻**.

---

## ⚙️ Réglages (bouton engrenage dans le panneau)

### Traduction
- **MyMemory** : gratuit, sans clé (par défaut).
- **DeepL** : collez votre **clé API**. Gratuite sur
  <https://www.deepl.com/pro-api> (500 000 caractères/mois). Les clés gratuites finissent
  par « :fx ». Les autres traductions (« Autres traductions ») restent fournies par MyMemory.

### OCR
- **Tesseract** : local, gratuit, correct sur texte net, variable sur manga.
- **IA vision** : envoie l'image au modèle (GPT ou Claude) pour transcription — **le meilleur
  choix pour le manga**. Nécessite une clé IA (ci-dessous).

### Assistant IA (explications + OCR vision)
- Choisissez **OpenAI** ou **Anthropic (Claude)**, collez la **clé**, et au besoin ajustez le
  **modèle** (défaut : `gpt-4o-mini` ou `claude-3-5-sonnet-latest` — modifiez selon vos accès).
- Clés : OpenAI <https://platform.openai.com/api-keys> · Anthropic <https://console.anthropic.com>.
- 🔒 Les clés sont stockées **localement** dans votre navigateur, et envoyées uniquement au
  service choisi.

---

## ▶️ Utilisation
1. Sur n'importe quel site, cliquez l'icône **LJ** → la **bulle** apparaît et le **panneau**
   s'ouvre à droite.
2. Placez/redimensionnez la bulle sur le texte ; réglez sa **forme** avec ◇ si besoin.
3. **« Traduire »** → lecture, traduction, affichage à droite.
4. Dans le panneau : **🔊** écouter, **autres traductions** cliquables, **Enregistrer**,
   **« Expliquer & apprendre (IA) »** pour les nuances + rōmaji.
5. Onglet **Vocabulaire** → **Flashcards** et **Quiz** sur vos mots enregistrés.

**Toujours fiable** : vous pouvez coller/taper du texte directement et traduire, sans capture.

---

## 🛠️ Dépannage
- **L'OCR Tesseract échouait** → corrigé en v0.3. Si une erreur persiste, ouvrez
  « Inspecter les vues : panneau latéral » (sous la carte de l'extension) et envoyez-moi le
  message de la console.
- **DeepL renvoie 403** → clé invalide, ou clé « Pro » utilisée sur l'endpoint gratuit
  (et inversement). Les clés gratuites finissent par « :fx ».
- **IA renvoie une erreur de modèle** → mettez un nom de modèle valide pour votre compte dans
  le champ « Modèle ».
- **La bulle n'apparaît pas** → page interne du navigateur (`chrome://`, Web Store) :
  l'injection y est interdite. La saisie manuelle fonctionne quand même.
- **Pas de son japonais** → ajoutez la voix japonaise dans les réglages de votre système.

---

## 🗂️ Structure
```
manifest.json   background.js   content.js (bulle + forme)
sidepanel.html  sidepanel.js (OCR/DeepL/IA/rōmaji/flashcards/quiz)
home.html/.js (démo)   lib/ (Tesseract)   traineddata/   icons/
```

Le-J traduit · Comprendre aujourd'hui. Maîtriser demain.
