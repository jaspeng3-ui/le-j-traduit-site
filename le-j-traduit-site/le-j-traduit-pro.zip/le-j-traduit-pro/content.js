// Le-J traduit — bulle flottante + traduction attachée (content script) v0.4
(function () {
  "use strict";
  if (window.__ljInjected) {
    const ex = document.getElementById("lj-traduit-host");
    if (ex) ex.style.display = "block";
    return;
  }
  window.__ljInjected = true;

  const DEFAULT_HINT = "Placez sur le texte, puis « Traduire »";
  const SPEAK = { fr: "fr-FR", en: "en-US", ja: "ja-JP", ko: "ko-KR" };
  const SHAPES = [
    { key: "arrondi", r: "16px", label: "Arrondi" },
    { key: "rect",    r: "4px",  label: "Rectangle" },
    { key: "pill",    r: "30px", label: "Pilule" },
    { key: "ovale",   r: "50%",  label: "Ovale" }
  ];
  let shapeIdx = 0, lastTrans = "", lastTgt = "fr";

  const host = document.createElement("div");
  host.id = "lj-traduit-host";
  host.style.cssText = "position:fixed;z-index:2147483647;top:120px;left:120px;width:340px;height:210px;";
  const root = host.attachShadow({ mode: "open" });

  root.innerHTML = `
    <style>
      :host{ all:initial; }
      .box{ position:absolute; inset:0; border-radius:16px;
        border:2px solid #34e0ff; box-shadow:0 0 0 1px rgba(52,224,255,.4),0 0 30px -4px rgba(52,224,255,.55),0 18px 50px -16px rgba(0,0,0,.6);
        background:rgba(8,12,28,.06); font-family:"Segoe UI",system-ui,sans-serif; }
      .box.shooting{ border-color:transparent; box-shadow:none; }
      .box.shooting .bar,.box.shooting .grip,.box.shooting .corner,.box.shooting .hint{ opacity:0 !important; }
      .box.noCorners .corner{ display:none; }
      .scan{ position:absolute; left:3px; right:3px; height:34px; top:0; border-radius:8px; opacity:0; pointer-events:none;
        background:linear-gradient(180deg,rgba(52,224,255,0),rgba(52,224,255,.3),rgba(52,224,255,0));
        box-shadow:0 0 18px 2px rgba(52,224,255,.5); }
      .box.scanning .scan{ opacity:1; animation:sc 1.2s ease-in-out infinite; }
      @keyframes sc{ 0%{top:2px}50%{top:calc(100% - 36px)}100%{top:2px} }
      .corner{ position:absolute; width:16px; height:16px; border:3px solid #34e0ff; transition:opacity .15s; }
      .tl{ top:-2px; left:-2px; border-right:0; border-bottom:0; border-radius:6px 0 0 0 }
      .tr{ top:-2px; right:-2px; border-left:0; border-bottom:0; border-radius:0 6px 0 0 }
      .bl{ bottom:-2px; left:-2px; border-right:0; border-top:0; border-radius:0 0 0 6px }
      .br{ bottom:-2px; right:-2px; border-left:0; border-top:0; border-radius:0 0 6px 0 }
      .bar{ position:absolute; left:0; right:0; top:-40px; height:34px; display:flex; align-items:center; gap:6px;
        padding:0 6px 0 12px; border-radius:11px; cursor:grab; user-select:none; transition:opacity .15s;
        background:linear-gradient(120deg,rgba(20,28,60,.96),rgba(12,18,42,.96)); border:1px solid rgba(120,150,255,.3);
        box-shadow:0 10px 30px -12px rgba(0,0,0,.7); }
      .bar:active{ cursor:grabbing }
      .lj{ font-weight:700; font-size:12.5px; color:#cfe2ff; margin-right:auto; display:flex; align-items:center; gap:7px }
      .dot{ width:8px;height:8px;border-radius:50%;background:linear-gradient(120deg,#34e0ff,#9b6cff);box-shadow:0 0 8px #34e0ff}
      button{ all:unset; cursor:pointer; font-family:inherit }
      .go{ display:flex;align-items:center;gap:6px; font-size:12px; font-weight:700; color:#06122a;
        background:linear-gradient(120deg,#34e0ff,#9b6cff); padding:6px 11px; border-radius:9px; }
      .go:hover{ filter:brightness(1.08) }
      .ic{ width:26px;height:26px;display:grid;place-items:center;border-radius:8px;color:#9aa4c8 }
      .ic:hover{ background:rgba(255,255,255,.08);color:#fff }
      .grip{ position:absolute; right:-3px; bottom:-3px; width:18px; height:18px; cursor:nwse-resize; transition:opacity .15s }
      .hint{ position:absolute; left:8px; bottom:-26px; font-size:11px; color:#bcd3ff;
        background:rgba(8,12,28,.85); padding:3px 9px; border-radius:8px; border:1px solid rgba(120,150,255,.25);
        white-space:nowrap; pointer-events:none; transition:opacity .15s }

      /* carte de traduction attachée à la bulle */
      .tcard{ position:absolute; left:0; top:calc(100% + 12px); width:max(260px,100%); max-width:380px; box-sizing:border-box;
        border-radius:14px; padding:12px 13px; display:none; backdrop-filter:blur(8px);
        background:linear-gradient(160deg,rgba(18,26,58,.97),rgba(12,18,42,.98)); border:1.5px solid rgba(52,224,255,.5);
        box-shadow:0 0 0 1px rgba(52,224,255,.3),0 0 26px -6px rgba(52,224,255,.5),0 18px 40px -16px rgba(0,0,0,.7); animation:pop .25s ease }
      @keyframes pop{ from{opacity:0;transform:translateY(-6px)} to{opacity:1;transform:none} }
      .tch{ display:flex; align-items:center; gap:7px; font-size:11.5px; font-weight:700; color:#34e0ff; margin-bottom:7px }
      .tch svg{ filter:drop-shadow(0 0 6px #34e0ff) }
      .tspk{ margin-left:auto; width:26px;height:26px;border-radius:8px;display:grid;place-items:center;color:#9aa4c8;
        background:rgba(120,140,220,.1);border:1px solid rgba(120,150,255,.25); }
      .tspk:hover{ color:#cfe2ff }
      .ttext{ font-size:15px; font-weight:600; line-height:1.4; color:#fff; word-break:break-word }
      .tload{ color:#9fb4e0; font-weight:500; font-size:13px; display:inline-flex; align-items:center; gap:8px }
      .tload::before{ content:""; width:13px;height:13px;border-radius:50%;border:2px solid rgba(52,224,255,.35);border-top-color:#34e0ff;display:inline-block;animation:spin .7s linear infinite }
      @keyframes spin{ to{transform:rotate(360deg)} }
      .torig{ font-size:11.5px; color:#7e89ad; font-style:italic; margin-top:6px; word-break:break-word }
    </style>
    <div class="box" id="box">
      <span class="corner tl"></span><span class="corner tr"></span>
      <span class="corner bl"></span><span class="corner br"></span>
      <div class="scan"></div>
      <div class="bar" id="bar">
        <span class="lj"><span class="dot"></span>Le-J</span>
        <button class="go" id="go" title="Lire et traduire la zone">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#06122a" stroke-width="2.2"><path d="M4 5h11M9 3v2m1 0s-1 6-5 9M14 21l4-9 4 9m-6.5-2.5h5"/></svg>
          Traduire
        </button>
        <button class="ic" id="shape" title="Changer la forme de la bulle">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="8" height="8" rx="1.5"/><circle cx="17" cy="17" r="4"/><path d="M14 3h7v7"/></svg>
        </button>
        <button class="ic" id="close" title="Fermer">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
      </div>
      <div class="grip" id="grip" title="Redimensionner">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34e0ff" stroke-width="2"><path d="M21 21H3M21 21V3M21 21l-9-9"/></svg>
      </div>
      <div class="tcard" id="tcard">
        <div class="tch"><svg width="12" height="12" viewBox="0 0 24 24" fill="#34e0ff"><path d="M12 2l1.5 6L20 9.5 13.5 11 12 18l-1.5-7L4 9.5 10.5 8z"/></svg> Traduction
          <button class="tspk" id="tspk" title="Écouter"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 9v6h4l5 4V5L8 9zM17 8a5 5 0 010 8"/></svg></button>
        </div>
        <div class="ttext" id="ttext"></div>
        <div class="torig" id="torig"></div>
      </div>
      <div class="hint" id="hint">${DEFAULT_HINT}</div>
    </div>`;

  document.documentElement.appendChild(host);
  const box = root.getElementById("box");
  const bar = root.getElementById("bar");
  const grip = root.getElementById("grip");
  const hint = root.getElementById("hint");
  const tcard = root.getElementById("tcard");
  const ttext = root.getElementById("ttext");
  const torig = root.getElementById("torig");

  // ---- carte de traduction ----
  function placeCard() {
    requestAnimationFrame(() => {
      tcard.style.top = ""; tcard.style.bottom = "";
      const hr = host.getBoundingClientRect(), ch = tcard.offsetHeight;
      if (hr.bottom + 12 + ch > window.innerHeight - 8 && hr.top - 12 - ch > 8) {
        tcard.style.bottom = "calc(100% + 12px)"; tcard.style.top = "auto";
      } else { tcard.style.top = "calc(100% + 12px)"; tcard.style.bottom = "auto"; }
    });
  }
  function showTransLoading() {
    tcard.style.display = "block";
    ttext.innerHTML = '<span class="tload">Lecture & traduction…</span>';
    torig.textContent = "";
    placeCard();
  }
  function showTransResult(orig, trans, romaji, tgt) {
    lastTrans = trans || ""; lastTgt = tgt || "fr";
    tcard.style.display = "block";
    ttext.textContent = trans || "(vide)";
    torig.textContent = orig ? (romaji ? orig + " — " + romaji : orig) : (romaji || "");
    placeCard();
  }
  function ljSpeak(text, lang) {
    if (!text) return;
    try { window.speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text); u.lang = lang || "fr-FR"; window.speechSynthesis.speak(u); } catch (e) {}
  }
  root.getElementById("tspk").addEventListener("click", () => ljSpeak(lastTrans, SPEAK[lastTgt] || "fr-FR"));

  // reçoit le résultat depuis le panneau (relayé par le service worker)
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "LJ_SHOW_TRANSLATION") showTransResult(msg.original, msg.translation, msg.romaji, msg.tgtLang);
  });

  // ---- forme ----
  function applyShape(silent) {
    const s = SHAPES[shapeIdx];
    box.style.borderRadius = s.r;
    box.classList.toggle("noCorners", s.key === "ovale");
    if (!silent) { hint.textContent = "Forme : " + s.label; setTimeout(() => { hint.textContent = DEFAULT_HINT; }, 1200); }
  }
  try { chrome.storage.local.get("bubbleShape", (o) => { const i = SHAPES.findIndex((x) => x.key === o.bubbleShape); if (i >= 0) shapeIdx = i; applyShape(true); }); } catch (e) {}
  root.getElementById("shape").addEventListener("click", () => {
    shapeIdx = (shapeIdx + 1) % SHAPES.length; applyShape(false);
    try { chrome.storage.local.set({ bubbleShape: SHAPES[shapeIdx].key }); } catch (e) {}
  });

  // ---- déplacement ----
  let drag = null;
  bar.addEventListener("pointerdown", (e) => { if (e.target.closest("button")) return; drag = { x: e.clientX, y: e.clientY, l: host.offsetLeft, t: host.offsetTop }; bar.setPointerCapture(e.pointerId); });
  bar.addEventListener("pointermove", (e) => { if (!drag) return; host.style.left = Math.max(0, drag.l + (e.clientX - drag.x)) + "px"; host.style.top = Math.max(0, drag.t + (e.clientY - drag.y)) + "px"; if (tcard.style.display === "block") placeCard(); });
  bar.addEventListener("pointerup", () => { drag = null; });

  // ---- redimensionnement ----
  let rez = null;
  grip.addEventListener("pointerdown", (e) => { e.stopPropagation(); rez = { x: e.clientX, y: e.clientY, w: host.offsetWidth, h: host.offsetHeight }; grip.setPointerCapture(e.pointerId); });
  grip.addEventListener("pointermove", (e) => { if (!rez) return; host.style.width = Math.max(120, rez.w + (e.clientX - rez.x)) + "px"; host.style.height = Math.max(90, rez.h + (e.clientY - rez.y)) + "px"; });
  grip.addEventListener("pointerup", () => { rez = null; });

  root.getElementById("close").addEventListener("click", () => { host.style.display = "none"; });

  // ---- traduire ----
  root.getElementById("go").addEventListener("click", () => {
    showTransLoading();
    hint.textContent = "Capture en cours…";
    box.classList.add("shooting");
    requestAnimationFrame(() => requestAnimationFrame(() => {
      const r = host.getBoundingClientRect();
      chrome.runtime.sendMessage({ type: "LJ_CAPTURE", rect: { x: r.left, y: r.top, width: r.width, height: r.height }, dpr: window.devicePixelRatio || 1 }).catch(() => {});
      setTimeout(() => {
        box.classList.remove("shooting");
        box.classList.add("scanning");
        hint.textContent = "Analyse en cours…";
        setTimeout(() => { box.classList.remove("scanning"); hint.textContent = DEFAULT_HINT; }, 1600);
      }, 450);
    }));
  });
})();
