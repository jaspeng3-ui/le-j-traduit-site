// Le-J traduit — logique du panneau latéral v0.3
(function () {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const statusEl = $("status"), statusText = $("statusText");
  const srcSel = $("src"), tgtSel = $("tgt"), vertCb = $("vert");
  const origTA = $("orig"), transEl = $("trans"), altsEl = $("alts"), engBadge = $("engBadge");
  const preview = $("preview"), aiCard = $("aiCard"), aiOut = $("aiOut"), aiAddVocab = $("aiAddVocab");
  const review = $("review"), vocabListEl = $("vocabList");

  function status(text, kind) {
    statusText.textContent = text;
    statusEl.className = "status" + (kind === "err" ? " err" : kind === "ok" ? " ok" : kind === "idle" ? " idle" : "");
  }

  // ============== RÉGLAGES ==============
  const DEFAULTS = { transEngine: "mymemory", deeplKey: "", ocrEngine: "tesseract", aiProvider: "none", aiKey: "", aiModel: "" };
  let settings = Object.assign({}, DEFAULTS);
  function loadSettings() { return new Promise((res) => chrome.storage.local.get("settings", (o) => { settings = Object.assign({}, DEFAULTS, o.settings || {}); res(); })); }
  function saveSettings() { return new Promise((res) => chrome.storage.local.set({ settings }, res)); }

  function bindSettings() {
    document.querySelectorAll("input[name=transEngine]").forEach((r) => r.checked = (r.value === settings.transEngine));
    document.querySelectorAll("input[name=ocrEngine]").forEach((r) => r.checked = (r.value === settings.ocrEngine));
    document.querySelectorAll("input[name=aiProvider]").forEach((r) => r.checked = (r.value === settings.aiProvider));
    $("deeplKey").value = settings.deeplKey || "";
    $("aiKey").value = settings.aiKey || "";
    $("aiModel").value = settings.aiModel || "";
  }
  document.querySelectorAll("input[name=aiProvider]").forEach((r) => r.addEventListener("change", () => {
    if (!$("aiModel").value) $("aiModel").placeholder = r.value === "anthropic" ? "Modèle (ex. claude-3-5-sonnet-latest)" : "Modèle (ex. gpt-4o-mini)";
  }));
  function toggleSettings(show) {
    $("settingsUI").style.display = show ? "block" : "none";
    $("mainUI").style.display = show ? "none" : "block";
    $("gearBtn").classList.toggle("on", show);
    if (show) bindSettings();
  }
  $("gearBtn").addEventListener("click", () => toggleSettings($("settingsUI").style.display === "none"));
  $("closeSettings").addEventListener("click", () => toggleSettings(false));
  $("saveSettings").addEventListener("click", async () => {
    settings.transEngine = (document.querySelector("input[name=transEngine]:checked") || {}).value || "mymemory";
    settings.ocrEngine = (document.querySelector("input[name=ocrEngine]:checked") || {}).value || "tesseract";
    settings.aiProvider = (document.querySelector("input[name=aiProvider]:checked") || {}).value || "none";
    settings.deeplKey = $("deeplKey").value.trim();
    settings.aiKey = $("aiKey").value.trim();
    settings.aiModel = $("aiModel").value.trim();
    await saveSettings();
    toggleSettings(false);
    status("Réglages enregistrés ✓", "ok");
  });

  // ============== LANGUES ==============
  const SPEAK = { ja: "ja-JP", en: "en-US", ko: "ko-KR", fr: "fr-FR" };
  const OCRLANG = { ja: "jpn", en: "eng", ko: "kor" };
  function detectLang(t) {
    if (/[\u3040-\u30ff\u4e00-\u9fff]/.test(t)) return "ja";
    if (/[\uac00-\ud7af\u1100-\u11ff]/.test(t)) return "ko";
    return "en";
  }
  function effectiveSrc(text) { return srcSel.value === "auto" ? detectLang(text || origTA.value) : srcSel.value; }
  function ocrLangCode() {
    const s = srcSel.value;
    if (s === "auto") return "jpn+eng";
    if (s === "ja") return vertCb.checked ? "jpn_vert" : "jpn";
    return OCRLANG[s] || "eng";
  }

  // ============== RŌMAJI (kana, intégré) ==============
  const H2 = { "きゃ":"kya","きゅ":"kyu","きょ":"kyo","しゃ":"sha","しゅ":"shu","しょ":"sho","ちゃ":"cha","ちゅ":"chu","ちょ":"cho","にゃ":"nya","にゅ":"nyu","にょ":"nyo","ひゃ":"hya","ひゅ":"hyu","ひょ":"hyo","みゃ":"mya","みゅ":"myu","みょ":"myo","りゃ":"rya","りゅ":"ryu","りょ":"ryo","ぎゃ":"gya","ぎゅ":"gyu","ぎょ":"gyo","じゃ":"ja","じゅ":"ju","じょ":"jo","びゃ":"bya","びゅ":"byu","びょ":"byo","ぴゃ":"pya","ぴゅ":"pyu","ぴょ":"pyo" };
  const H1 = { "あ":"a","い":"i","う":"u","え":"e","お":"o","か":"ka","き":"ki","く":"ku","け":"ke","こ":"ko","さ":"sa","し":"shi","す":"su","せ":"se","そ":"so","た":"ta","ち":"chi","つ":"tsu","て":"te","と":"to","な":"na","に":"ni","ぬ":"nu","ね":"ne","の":"no","は":"ha","ひ":"hi","ふ":"fu","へ":"he","ほ":"ho","ま":"ma","み":"mi","む":"mu","め":"me","も":"mo","や":"ya","ゆ":"yu","よ":"yo","ら":"ra","り":"ri","る":"ru","れ":"re","ろ":"ro","わ":"wa","を":"wo","ん":"n","が":"ga","ぎ":"gi","ぐ":"gu","げ":"ge","ご":"go","ざ":"za","じ":"ji","ず":"zu","ぜ":"ze","ぞ":"zo","だ":"da","ぢ":"ji","づ":"zu","で":"de","ど":"do","ば":"ba","び":"bi","ぶ":"bu","べ":"be","ぼ":"bo","ぱ":"pa","ぴ":"pi","ぷ":"pu","ぺ":"pe","ぽ":"po","ぁ":"a","ぃ":"i","ぅ":"u","ぇ":"e","ぉ":"o","ゃ":"ya","ゅ":"yu","ょ":"yo","ゔ":"vu","、":", ","。":". ","　":" " };
  function kataToHira(ch) {
    const c = ch.charCodeAt(0);
    if (c >= 0x30a1 && c <= 0x30f6) return String.fromCharCode(c - 0x60);
    return ch;
  }
  function kanaRomaji(text) {
    // normaliser katakana -> hiragana (en gardant ー)
    let s = "";
    for (const ch of text) { s += (ch === "ー" ? "ー" : kataToHira(ch)); }
    let out = "", gem = false;
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (c === "っ") { gem = true; continue; }
      if (c === "ー") { const m = out.match(/[aeiou]$/); if (m) out += m[0]; continue; }
      let r = H2[s.substr(i, 2)];
      if (r) i++; else r = H1[c];
      if (r == null) { out += c; continue; }
      if (gem && /^[a-z]/.test(r)) { r = r.startsWith("ch") ? "t" + r : r[0] + r; gem = false; }
      out += r;
    }
    return out;
  }
  function setRomaji(text, accurate) {
    const el = $("romaji");
    if (!text) { el.classList.remove("show"); el.innerHTML = ""; return; }
    el.innerHTML = '<span class="lbl">' + (accurate ? "Lecture" : "Lecture approx.") + "</span>" + escapeHtml(text);
    el.classList.add("show");
  }
  function updateRomajiInstant() {
    const t = origTA.value;
    if (!/[\u3040-\u30ff]/.test(t)) { setRomaji("", false); return; }
    setRomaji(kanaRomaji(t), !/[\u4e00-\u9fff]/.test(t));
  }
  origTA.addEventListener("input", updateRomajiInstant);

  // ============== OCR Tesseract (correctif worker MV3) ==============
  let worker = null, workerLang = "";
  async function getWorker(lang) {
    if (worker && workerLang === lang) return worker;
    if (worker) { try { await worker.terminate(); } catch (e) {} worker = null; }
    status("Chargement du moteur OCR…");
    worker = await Tesseract.createWorker(lang, 1, {
      workerPath: chrome.runtime.getURL("lib/worker.min.js"),
      corePath: chrome.runtime.getURL("lib/core/"),
      langPath: chrome.runtime.getURL("traineddata/"),
      workerBlobURL: false,   // <-- correctif : charge le worker en direct (même origine), pas via un Blob
      logger: (m) => { if (m && m.status) { const p = m.progress ? " " + Math.round(m.progress * 100) + "%" : ""; status(m.status.charAt(0).toUpperCase() + m.status.slice(1) + p); } }
    });
    try { await worker.setParameters({ tessedit_pageseg_mode: lang.indexOf("vert") >= 0 ? "5" : "6" }); } catch (e) {}
    workerLang = lang;
    return worker;
  }

  // ============== OCR par IA vision (manga) ==============
  async function ocrWithAI(dataUrl) {
    const sl = srcSel.value;
    const what = sl === "auto" ? "le texte" : ({ ja: "le texte japonais", en: "le texte anglais", ko: "le texte coréen" }[sl] || "le texte");
    const txt = await callAI({
      system: "Tu es un moteur OCR expert, spécialisé dans le manga et les bulles de bande dessinée. Transcris fidèlement le texte présent dans l'image. Conserve les sauts de ligne. Réponds UNIQUEMENT par le texte transcrit, sans guillemets, sans traduction et sans aucun commentaire.",
      user: "Transcris " + what + " présent dans cette image.",
      imageDataUrl: dataUrl
    });
    return (txt || "").trim();
  }

  // ============== Réception de l'image capturée ==============
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === "LJ_IMAGE") handleImage(msg.dataUrl, msg.rect, msg.dpr, msg.tabId);
    else if (msg.type === "LJ_CAPTURE_ERROR") status("Capture impossible : " + msg.error + ". Essayez la saisie manuelle.", "err");
    else if (msg.type === "LJ_STATUS") status(msg.text, "idle");
  });
  function loadImage(src) { return new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; }); }

  // binarisation Otsu + auto-inversion : améliore nettement Tesseract sur texte net
  function preprocess(cv) {
    const ctx = cv.getContext("2d"); const img = ctx.getImageData(0, 0, cv.width, cv.height); const d = img.data;
    const total = cv.width * cv.height; const gray = new Uint8Array(total); const hist = new Array(256).fill(0);
    for (let i = 0, p = 0; i < d.length; i += 4, p++) { const g = (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114) | 0; gray[p] = g; hist[g]++; }
    let sum = 0; for (let t = 0; t < 256; t++) sum += t * hist[t];
    let sumB = 0, wB = 0, maxVar = -1, thr = 127;
    for (let t = 0; t < 256; t++) { wB += hist[t]; if (!wB) continue; const wF = total - wB; if (!wF) break; sumB += t * hist[t]; const mB = sumB / wB, mF = (sum - sumB) / wF; const v = wB * wF * (mB - mF) * (mB - mF); if (v > maxVar) { maxVar = v; thr = t; } }
    let dark = 0; for (let p = 0; p < total; p++) if (gray[p] < thr) dark++;
    const invert = dark > total / 2;
    for (let i = 0, p = 0; i < d.length; i += 4, p++) { let v = gray[p] < thr ? 0 : 255; if (invert) v = 255 - v; d[i] = d[i + 1] = d[i + 2] = v; }
    ctx.putImageData(img, 0, 0);
  }

  function romajiText() { const el = $("romaji"); if (!el.classList.contains("show")) return ""; return el.textContent.replace(/^Lecture(\s*approx\.)?/, "").trim(); }
  let currentTabId = null;
  function notifyPage(original, translation, romaji) {
    if (currentTabId == null) return;
    chrome.runtime.sendMessage({ type: "LJ_RESULT", tabId: currentTabId, original, translation, romaji, tgtLang: tgtSel.value }).catch(() => {});
  }

  async function handleImage(dataUrl, rect, dpr, tabId) {
    if (tabId != null) currentTabId = tabId;
    try {
      const img = await loadImage(dataUrl);
      const sw = rect.width * dpr, sh = rect.height * dpr;
      const scale = Math.max(1, Math.min(4, 700 / Math.max(1, Math.min(sw, sh))));
      const cv = document.createElement("canvas");
      cv.width = Math.max(1, Math.round(sw * scale));
      cv.height = Math.max(1, Math.round(sh * scale));
      const ctx = cv.getContext("2d");
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(img, rect.x * dpr, rect.y * dpr, sw, sh, 0, 0, cv.width, cv.height);
      const crop = cv.toDataURL("image/png");
      preview.src = crop; preview.style.display = "block";

      let text = "";
      if (settings.ocrEngine === "ai" && settings.aiProvider !== "none" && settings.aiKey) {
        status("Lecture par IA vision…");
        text = await ocrWithAI(crop);
      } else {
        if (settings.ocrEngine === "ai") status("IA non configurée → Tesseract utilisé.");
        const w = await getWorker(ocrLangCode());
        status("Lecture du texte…");
        preprocess(cv);
        const { data } = await w.recognize(cv);
        text = (data.text || "").replace(/\s+\n/g, "\n").trim();
      }
      if (text) {
        origTA.value = text; updateRomajiInstant();
        status("Texte détecté ✓ — traduction…", "ok");
        await translate();
        notifyPage(origTA.value, lastTranslation || "(traduction indisponible)", romajiText());
      } else {
        status("Aucun texte net détecté. Resserrez la zone, cochez « vertical », ou passez l'OCR en « IA vision » (Réglages ⚙️) — bien meilleur sur le manga.", "err");
        notifyPage("", "(aucun texte net détecté)", "");
      }
    } catch (e) {
      console.error(e);
      status("Erreur OCR : " + (e && e.message ? e.message : e) + ". La saisie manuelle reste possible.", "err");
      notifyPage("", "Erreur — voir le panneau", "");
    }
  }

  // ============== TRADUCTION ==============
  let lastTranslation = "";
  function setTrans(t, dim, engine) {
    engBadge.innerHTML = engine ? '<span class="eng-badge">' + engine + "</span>" : "";
    transEl.innerHTML = "";
    if (dim) { transEl.innerHTML = '<span class="muted">' + escapeHtml(t) + "</span>"; lastTranslation = ""; }
    else { transEl.textContent = t; lastTranslation = t; }
  }
  function dedupe(a) { const s = new Set(), o = []; for (const x of a) { const k = (x || "").trim().toLowerCase(); if (x && !s.has(k)) { s.add(k); o.push(x.trim()); } } return o; }

  async function translate() {
    const text = origTA.value.trim();
    if (!text) { status("Rien à traduire.", "idle"); return; }
    const src = effectiveSrc(text), tgt = tgtSel.value;
    if (src === tgt) { setTrans(text, false, "—"); markSaveable(); status("Source et cible identiques.", "idle"); return; }
    status("Traduction…");
    altsEl.innerHTML = "";
    try {
      let main = "", engine = "MyMemory";
      if (settings.transEngine === "deepl" && settings.deeplKey) { main = await translateDeepL(text, src, tgt); engine = "DeepL"; }
      else { if (settings.transEngine === "deepl") status("DeepL non configuré → MyMemory."); main = await translateMyMemory(text, src, tgt); }
      setTrans(main, false, engine);
      fetchAlternatives(text, src, tgt, main);
      markSaveable();
      addHistory(text, main, src, tgt);
      status("Traduction prête ✓", "ok");
    } catch (e) { console.error(e); status("Erreur de traduction : " + (e && e.message ? e.message : e), "err"); }
  }
  async function translateMyMemory(text, src, tgt) {
    const url = "https://api.mymemory.translated.net/get?q=" + encodeURIComponent(text) + "&langpair=" + src + "|" + tgt;
    const r = await fetch(url); const j = await r.json();
    const main = (j.responseData && j.responseData.translatedText) || "";
    if (!main) throw new Error("réponse vide"); return main;
  }
  async function translateDeepL(text, src, tgt) {
    const TGT = { fr: "FR", en: "EN-US" }[tgt] || "FR";
    const SRC = { ja: "JA", en: "EN", ko: "KO" }[src];
    const key = settings.deeplKey.trim();
    const endpoint = key.endsWith(":fx") ? "https://api-free.deepl.com/v2/translate" : "https://api.deepl.com/v2/translate";
    const p = new URLSearchParams(); p.append("text", text); p.append("target_lang", TGT); if (SRC) p.append("source_lang", SRC);
    const r = await fetch(endpoint, { method: "POST", headers: { "Authorization": "DeepL-Auth-Key " + key, "Content-Type": "application/x-www-form-urlencoded" }, body: p.toString() });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.message || ("DeepL HTTP " + r.status));
    return j.translations[0].text;
  }
  async function fetchAlternatives(text, src, tgt, main) {
    try {
      const url = "https://api.mymemory.translated.net/get?q=" + encodeURIComponent(text) + "&langpair=" + src + "|" + tgt;
      const r = await fetch(url); const j = await r.json();
      const alts = dedupe((j.matches || []).map((m) => m.translation)).filter((t) => t.toLowerCase() !== main.toLowerCase()).slice(0, 3);
      renderAlts(alts);
    } catch (e) {}
  }
  function renderAlts(list) {
    altsEl.innerHTML = "";
    list.forEach((t) => {
      const d = document.createElement("div");
      d.className = "alt"; d.title = "Utiliser cette traduction";
      d.innerHTML = '<span class="d"></span><span>' + escapeHtml(t) + "</span>";
      d.addEventListener("click", () => { setTrans(t, false, engBadge.textContent || ""); markSaveable(); });
      altsEl.appendChild(d);
    });
  }

  // ============== IA (OpenAI / Anthropic) ==============
  async function callAI(opts) {
    const p = settings.aiProvider;
    if (p === "none" || !settings.aiKey) throw new Error("Aucune IA configurée (Réglages ⚙️).");
    const model = settings.aiModel || (p === "openai" ? "gpt-4o-mini" : "claude-3-5-sonnet-latest");
    if (p === "openai") {
      const content = opts.imageDataUrl ? [{ type: "text", text: opts.user }, { type: "image_url", image_url: { url: opts.imageDataUrl } }] : opts.user;
      const body = { model, max_tokens: 800, temperature: 0.3, messages: [{ role: "system", content: opts.system }, { role: "user", content }] };
      if (opts.json) body.response_format = { type: "json_object" };
      const r = await fetch("https://api.openai.com/v1/chat/completions", { method: "POST", headers: { "Content-Type": "application/json", "Authorization": "Bearer " + settings.aiKey }, body: JSON.stringify(body) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error((j.error && j.error.message) || ("OpenAI HTTP " + r.status));
      return j.choices[0].message.content;
    } else {
      let content;
      if (opts.imageDataUrl) { const b64 = opts.imageDataUrl.split(",")[1]; content = [{ type: "text", text: opts.user }, { type: "image", source: { type: "base64", media_type: "image/png", data: b64 } }]; }
      else content = [{ type: "text", text: opts.user }];
      const body = { model, max_tokens: 800, system: opts.system, messages: [{ role: "user", content }] };
      const r = await fetch("https://api.anthropic.com/v1/messages", { method: "POST", headers: { "content-type": "application/json", "x-api-key": settings.aiKey, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" }, body: JSON.stringify(body) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error((j.error && j.error.message) || ("Anthropic HTTP " + r.status));
      return (j.content || []).map((b) => b.text || "").join("");
    }
  }
  function parseJSON(s) { const m = s.match(/\{[\s\S]*\}/); return JSON.parse(m ? m[0] : s); }
  let lastAIVocab = [];
  async function explain() {
    const o = origTA.value.trim();
    if (!o) { status("Rien à expliquer.", "idle"); return; }
    aiCard.style.display = "block"; aiAddVocab.style.display = "none";
    if (settings.aiProvider === "none" || !settings.aiKey) { aiOut.innerHTML = '<p class="muted">Configurez une IA (OpenAI ou Claude) dans les Réglages ⚙️ pour activer les explications et le rōmaji complet.</p>'; return; }
    aiOut.innerHTML = '<p class="muted">Analyse par l\'IA…</p>';
    const src = effectiveSrc(o), tgt = tgtSel.value;
    try {
      const raw = await callAI({
        json: true,
        system: "Tu es un professeur de langues bienveillant. Tu expliques en français, clairement et brièvement.",
        user: "Phrase (langue source = " + src + ") : « " + o + " »\nTraduction (" + tgt + ") : « " + (lastTranslation || "(non traduite)") + " »\n\nRéponds STRICTEMENT en JSON valide, sans texte autour, au format :\n{\"romaji\":\"lecture complète en rōmaji (vide si non pertinent)\",\"explication\":\"2-3 phrases sur le sens\",\"nuances\":\"1-2 phrases sur le registre, le ton, la grammaire ou le contexte\",\"vocab\":[{\"mot\":\"\",\"lecture\":\"\",\"sens\":\"\"}]}\nLimite vocab à 5 mots-clés importants."
      });
      renderAI(parseJSON(raw));
    } catch (e) { aiOut.innerHTML = '<p class="muted">Erreur IA : ' + escapeHtml(e && e.message ? e.message : String(e)) + "</p>"; }
  }
  function renderAI(d) {
    let html = "";
    if (d.romaji) { html += '<h4>Lecture (rōmaji)</h4><p style="color:var(--cyan);font-style:italic">' + escapeHtml(d.romaji) + "</p>"; setRomaji(d.romaji, true); }
    if (d.explication) html += "<h4>Explication</h4><p>" + escapeHtml(d.explication) + "</p>";
    if (d.nuances) html += "<h4>Nuances</h4><p>" + escapeHtml(d.nuances) + "</p>";
    if (d.vocab && d.vocab.length) {
      html += '<h4>Vocabulaire</h4><div class="ai-vocab">';
      d.vocab.forEach((v) => { html += '<div class="vw"><span class="w">' + escapeHtml(v.mot || "") + '</span><span class="r">' + escapeHtml(v.lecture || "") + '</span><span class="s">' + escapeHtml(v.sens || "") + "</span></div>"; });
      html += "</div>";
      lastAIVocab = d.vocab; aiAddVocab.style.display = "flex";
    }
    aiOut.innerHTML = html || '<p class="muted">Réponse vide.</p>';
  }
  aiAddVocab.addEventListener("click", async () => {
    if (!lastAIVocab.length) return;
    const list = await load("vocab"), src = effectiveSrc(), tgt = tgtSel.value;
    lastAIVocab.forEach((v) => { if (v.mot) list.unshift({ o: v.mot, t: v.sens || "", reading: v.lecture || "", src, tgt, ts: Date.now() }); });
    await save("vocab", list.slice(0, 500));
    aiAddVocab.lastChild.textContent = " Ajouté ✓";
    renderVocab();
  });
  $("explainBtn").addEventListener("click", explain);

  // ============== SYNTHÈSE VOCALE ==============
  let voices = [];
  function refreshVoices() { voices = window.speechSynthesis.getVoices() || []; }
  refreshVoices();
  if (typeof speechSynthesis !== "undefined") speechSynthesis.onvoiceschanged = refreshVoices;
  function speak(text, langCode, btn) {
    if (!text) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text); u.lang = langCode;
    const v = voices.find((x) => x.lang && x.lang.toLowerCase().startsWith(langCode.slice(0, 2)));
    if (v) u.voice = v;
    if (btn) { document.querySelectorAll(".spk.on").forEach((b) => b.classList.remove("on")); btn.classList.add("on"); u.onend = u.onerror = () => btn.classList.remove("on"); }
    window.speechSynthesis.speak(u);
  }
  $("spkOrig").addEventListener("click", () => speak(origTA.value.trim(), SPEAK[effectiveSrc()] || "ja-JP", $("spkOrig")));
  $("spkTrans").addEventListener("click", () => speak(lastTranslation, SPEAK[tgtSel.value] || "fr-FR", $("spkTrans")));

  // ============== STOCKAGE ==============
  function load(key) { return new Promise((res) => chrome.storage.local.get(key, (o) => res(o[key] || []))); }
  function save(key, val) { return new Promise((res) => chrome.storage.local.set({ [key]: val }, res)); }
  const saveBtn = $("saveBtn");
  function markSaveable() { saveBtn.classList.remove("done"); saveBtn.lastChild.textContent = " Enregistrer dans mon vocabulaire"; }
  saveBtn.addEventListener("click", async () => {
    const o = origTA.value.trim(), t = lastTranslation.trim();
    if (!o || !t) { status("Traduisez d'abord un texte.", "idle"); return; }
    const list = await load("vocab");
    list.unshift({ o, t, reading: ($("romaji").classList.contains("show") ? $("romaji").textContent.replace(/^Lecture(\sapprox\.)?/, "") : ""), src: effectiveSrc(o), tgt: tgtSel.value, ts: Date.now() });
    await save("vocab", list.slice(0, 500));
    saveBtn.classList.add("done"); saveBtn.lastChild.textContent = " Enregistré ✓"; renderVocab();
  });
  async function addHistory(o, t, src, tgt) {
    const list = await load("history");
    list.unshift({ o, t, src, tgt, ts: Date.now() });
    await save("history", list.slice(0, 200));
    if ($("p-hist").classList.contains("active")) renderHist();
  }
  function timeAgo(ts) {
    const d = new Date(ts), now = new Date();
    const same = d.toDateString() === now.toDateString();
    const hh = String(d.getHours()).padStart(2, "0"), mm = String(d.getMinutes()).padStart(2, "0");
    return (same ? "Aujourd'hui" : d.toLocaleDateString("fr-FR")) + " " + hh + ":" + mm;
  }
  function itemNode(it, key, idx) {
    const el = document.createElement("div"); el.className = "item";
    el.innerHTML = '<div class="body"><div class="o">' + escapeHtml(it.o) + '</div><div class="t">' + escapeHtml(it.t) + '</div><div class="meta">' + (it.src || "").toUpperCase() + " → " + (it.tgt || "").toUpperCase() + " · " + timeAgo(it.ts) + '</div></div><div class="acts"><button class="mini play" title="Écouter"><svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4l14 8-14 8z"/></svg></button><button class="mini del" title="Supprimer"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14"/></svg></button></div>';
    el.querySelector(".play").addEventListener("click", () => speak(it.o, SPEAK[it.src] || "ja-JP"));
    el.querySelector(".del").addEventListener("click", async () => { const l = await load(key); l.splice(idx, 1); await save(key, l); key === "vocab" ? renderVocab() : renderHist(); });
    return el;
  }
  async function renderVocab() {
    const list = await load("vocab"); vocabListEl.innerHTML = "";
    if (!list.length) { vocabListEl.innerHTML = '<div class="empty">Aucun mot enregistré.<br>Traduisez un texte puis « Enregistrer », ou utilisez « Ajouter aux flashcards » après une explication IA.</div>'; return; }
    list.forEach((it, i) => vocabListEl.appendChild(itemNode(it, "vocab", i)));
  }
  async function renderHist() {
    const wrap = $("histList"), list = await load("history"); wrap.innerHTML = "";
    if (!list.length) { wrap.innerHTML = '<div class="empty">Historique vide.<br>Chaque traduction s\'y ajoute automatiquement.</div>'; return; }
    list.forEach((it, i) => wrap.appendChild(itemNode(it, "history", i)));
  }

  // ============== FLASHCARDS & QUIZ ==============
  function shuffle(a) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function showReview() { review.style.display = "block"; vocabListEl.style.display = "none"; }
  function closeReview() { review.style.display = "none"; review.innerHTML = ""; vocabListEl.style.display = ""; renderVocab(); }
  function reviewMsg(msg) { showReview(); review.innerHTML = '<div class="empty">' + escapeHtml(msg) + '</div><button class="btn ghost" id="rvClose">Fermer</button>'; $("rvClose").addEventListener("click", closeReview); }

  $("fcBtn").addEventListener("click", async () => {
    const list = await load("vocab");
    if (!list.length) return reviewMsg("Enregistrez d'abord du vocabulaire.");
    const order = shuffle(list); let i = 0, flipped = false;
    showReview();
    function render() {
      const it = order[i];
      review.innerHTML = '<div class="progress">Carte ' + (i + 1) + " / " + order.length + '</div><div class="flash" id="fcard"><div class="front">' + escapeHtml(it.o) + "</div>" + (flipped ? '<div class="back">' + escapeHtml(it.t) + (it.reading ? " · " + escapeHtml(it.reading) : "") + "</div>" : '<div class="tap">Touchez pour révéler</div>') + '</div><div class="row2"><button class="btn ghost" id="fcPrev">‹ Préc.</button><button class="btn" id="fcNext">' + (i + 1 < order.length ? "Suivant ›" : "Terminer") + '</button></div><button class="btn ghost" id="fcClose">Fermer la révision</button>';
      $("fcard").addEventListener("click", () => { flipped = !flipped; render(); });
      $("fcNext").addEventListener("click", () => { if (i + 1 < order.length) { i++; flipped = false; render(); } else closeReview(); });
      $("fcPrev").addEventListener("click", () => { if (i > 0) { i--; flipped = false; render(); } });
      $("fcClose").addEventListener("click", closeReview);
    }
    render();
  });

  $("quizBtn").addEventListener("click", async () => {
    const list = await load("vocab");
    if (list.length < 4) return reviewMsg("Il faut au moins 4 mots enregistrés pour un quiz.");
    startQuiz(list);
  });
  function startQuiz(list) {
    const order = shuffle(list); let i = 0, score = 0;
    showReview();
    function render() {
      const it = order[i];
      const others = shuffle(list.filter((x) => x.o !== it.o)).slice(0, 3);
      const opts = shuffle([it].concat(others));
      review.innerHTML = '<div class="progress">Question ' + (i + 1) + " / " + order.length + " · Score " + score + '</div><div class="card"><div class="ch">Quel mot signifie :</div><div class="trans">' + escapeHtml(it.t) + '</div></div><div id="qopts"></div><button class="btn ghost" id="qClose">Fermer</button>';
      const wrap = $("qopts");
      opts.forEach((op) => {
        const b = document.createElement("button"); b.className = "qopt"; b.textContent = op.o;
        b.addEventListener("click", () => {
          if (wrap.dataset.done) return; wrap.dataset.done = "1";
          if (op.o === it.o) { b.classList.add("good"); score++; }
          else { b.classList.add("bad"); [...wrap.children].forEach((x) => { if (x.textContent === it.o) x.classList.add("good"); }); }
          setTimeout(() => { if (i + 1 < order.length) { i++; render(); } else finish(); }, 1100);
        });
        wrap.appendChild(b);
      });
      $("qClose").addEventListener("click", closeReview);
    }
    function finish() {
      review.innerHTML = '<div class="card"><div class="ch">Quiz terminé 🎉</div><div class="trans">Score : ' + score + " / " + order.length + '</div></div><button class="btn" id="qAgain">Recommencer</button><button class="btn ghost" id="qClose2">Fermer</button>';
      $("qAgain").addEventListener("click", () => startQuiz(list));
      $("qClose2").addEventListener("click", closeReview);
    }
    render();
  }

  // ============== ONGLETS & DIVERS ==============
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
      document.querySelectorAll(".pane").forEach((p) => p.classList.remove("active"));
      tab.classList.add("active"); $(tab.dataset.pane).classList.add("active");
      if (tab.dataset.pane === "p-vocab") { closeReview(); }
      if (tab.dataset.pane === "p-hist") renderHist();
    });
  });
  $("translateBtn").addEventListener("click", translate);
  origTA.addEventListener("keydown", (e) => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") translate(); });
  $("swap").addEventListener("click", () => {
    const s = srcSel.value, t = tgtSel.value;
    if (s !== "auto" && [...tgtSel.options].some((o) => o.value === s)) tgtSel.value = s;
    if ([...srcSel.options].some((o) => o.value === t)) srcSel.value = t;
  });
  $("demoBtn").addEventListener("click", () => chrome.runtime.sendMessage({ type: "LJ_OPEN_HOME" }).catch(() => {}));

  function escapeHtml(s) { return (s || "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

  // ============== INIT ==============
  loadSettings().then(() => { bindSettings(); });
})();
