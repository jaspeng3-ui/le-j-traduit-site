(function(){
  "use strict";
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---- ambient background bubbles ---- */
  (function(){
    var stage = document.getElementById('ljStage');
    var shapes = [
      {x:'6%',y:'14%',s:64},{x:'88%',y:'10%',s:90},{x:'14%',y:'72%',s:54},
      {x:'82%',y:'66%',s:74},{x:'46%',y:'6%',s:40},{x:'92%',y:'40%',s:48},{x:'4%',y:'44%',s:58}
    ];
    shapes.forEach(function(b,i){
      var d=document.createElement('div');
      d.className='lj-amb';
      d.style.left=b.x;d.style.top=b.y;
      d.style.animationDelay=(i*1.3)+'s';
      d.style.animationDuration=(13+i*1.5)+'s';
      d.innerHTML='<svg width="'+b.s+'" height="'+(b.s*.8)+'" viewBox="0 0 64 52" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="56" height="36" rx="11"/><path d="M18 44l-6 6v-6"/></svg>';
      stage.appendChild(d);
    });
  })();

  /* ---- build waveforms ---- */
  function buildWave(el){
    if(!el || el.dataset.built) return;
    var n = el.dataset.wavefor==='prono'||el.dataset.wavefor==='prono2' ? 26 : 30;
    for(var i=0;i<n;i++){
      var bar=document.createElement('i');
      var h=22+Math.round(Math.abs(Math.sin(i*0.9))*70);
      bar.style.height=h+'%';
      bar.style.animationDelay=(i*0.045)+'s';
      bar.style.animationDuration=(0.7+(i%5)*0.12)+'s';
      el.appendChild(bar);
    }
    el.dataset.built='1';
  }
  document.querySelectorAll('.lj-wave').forEach(buildWave);

  /* ---- audio playback (visual only) ---- */
  var playTimers = {};
  function stopAll(){
    document.querySelectorAll('[data-audio]').forEach(function(b){ b.classList.remove('is-playing'); });
    document.querySelectorAll('.lj-wave').forEach(function(w){ w.parentElement && w.parentElement.classList.remove('is-playing'); w.classList.remove('is-playing'); });
    Object.keys(playTimers).forEach(function(k){ clearTimeout(playTimers[k]); });
    playTimers={};
  }
  document.addEventListener('click', function(e){
    var btn = e.target.closest('[data-audio]');
    if(!btn) return;
    var key = btn.getAttribute('data-audio');
    var on = btn.classList.contains('is-playing');
    stopAll();
    if(on) return;
    // activate this button + matching waveform(s)
    document.querySelectorAll('[data-audio="'+key+'"]').forEach(function(b){ b.classList.add('is-playing'); });
    var waves = document.querySelectorAll('.lj-wave[data-wavefor="'+key+'"]');
    waves.forEach(function(w){ w.classList.add('is-playing'); });
    playTimers[key]=setTimeout(stopAll, reduce?300:3200);
  });

  /* ---- alternative translation swap ---- */
  var mainTrans = document.getElementById('ljMainTrans');
  var cardBody = document.getElementById('ljCardBody');
  document.querySelectorAll('.lj-alt').forEach(function(alt){
    alt.addEventListener('click', function(){
      document.querySelectorAll('.lj-alt').forEach(function(a){a.classList.remove('active');});
      alt.classList.add('active');
      var t = alt.getAttribute('data-alt');
      mainTrans.style.opacity=0;
      setTimeout(function(){ mainTrans.textContent=t; mainTrans.style.transition='opacity .3s'; mainTrans.style.opacity=1; },150);
      if(cardBody && document.getElementById('ljTransCard').classList.contains('done')){
        cardBody.textContent=t;
      }
    });
  });

  /* ---- OCR scan + translation reveal sequence ---- */
  var canvas=document.getElementById('ljCanvas');
  var frame=document.getElementById('ljFrame');
  var card=document.getElementById('ljTransCard');
  var tag=document.getElementById('ljCardTag');
  var pct=document.getElementById('ljCardPct');
  var dots=document.getElementById('ljCardDots').querySelectorAll('i');
  var panelTrans=document.getElementById('ljTransCardPanel');
  var origCard=document.getElementById('ljOrigCard');
  var FINAL='J\u2019ai vraiment l\u2019impression que ce monde a chang\u00e9.';
  var scanTimers=[];
  function clearScan(){ scanTimers.forEach(clearTimeout); scanTimers=[]; }

  function setPct(v){
    pct.textContent=v+'%';
    var lit=Math.round(v/100*dots.length);
    dots.forEach(function(d,i){ d.classList.toggle('on', i<lit); });
  }
  function animatePct(from,to,dur,cb){
    if(reduce){ setPct(to); cb&&cb(); return; }
    var start=performance.now();
    (function step(now){
      var p=Math.min(1,(now-start)/dur);
      setPct(Math.round(from+(to-from)*p));
      if(p<1) requestAnimationFrame(step); else cb&&cb();
    })(start);
  }

  function runScan(){
    clearScan();
    // 1. scanning state
    card.classList.remove('done');
    card.classList.add('scanning');
    canvas.classList.add('scanning');
    tag.innerHTML='<span class="lj-pulse"></span> OCR actif — Analyse en cours\u2026';
    cardBody.textContent='Reconnaissance du texte japonais\u2026';
    setPct(0);
    // right panel -> loading shimmer
    origCard.querySelector('.lj-jp').innerHTML='<div class="lj-shim" style="width:85%"></div><div class="lj-shim" style="width:60%;margin-top:8px"></div>';
    origCard.querySelector('.lj-romaji').style.visibility='hidden';
    panelTrans.querySelector('#ljMainTrans').innerHTML='<div class="lj-shim" style="width:90%"></div><div class="lj-shim" style="width:55%;margin-top:8px"></div>';
    panelTrans.classList.remove('glow');

    animatePct(0,72,1300);

    scanTimers.push(setTimeout(function(){
      // 2. done state
      card.classList.remove('scanning');
      canvas.classList.remove('scanning');
      card.classList.add('done');
      tag.innerHTML='Traduction <svg width="12" height="12" viewBox="0 0 24 24" fill="#34e0ff"><path d="M12 2l1.5 6L20 9.5 13.5 11 12 18l-1.5-7L4 9.5 10.5 8z"/></svg>';
      cardBody.textContent=FINAL;
      animatePct(72,98,700);
      // restore right panel
      origCard.querySelector('.lj-jp').textContent='\u3053\u306e\u4e16\u754c\u306f\u672c\u5f53\u306b\u5909\u308f\u3063\u305f\u6c17\u304c\u3059\u308b\u3002';
      origCard.querySelector('.lj-romaji').style.visibility='visible';
      var mt=panelTrans.querySelector('#ljMainTrans');
      mt.textContent=FINAL;
      panelTrans.classList.add('glow');
      // stagger reveal of panel cards
      var cards=document.querySelectorAll('#ljViewTranslate .lj-card');
      cards.forEach(function(c,i){
        c.classList.remove('lj-reveal'); void c.offsetWidth;
        c.style.animationDelay=(i*0.07)+'s';
        c.classList.add('lj-reveal');
      });
    }, reduce?300:1700));
  }

  document.getElementById('ljReplay').addEventListener('click', runScan);
  // auto-run once on load
  setTimeout(runScan, reduce?100:700);

  /* ---- mode apprentissage toggle ---- */
  var viewT=document.getElementById('ljViewTranslate');
  var viewL=document.getElementById('ljViewLearn');
  var sw1=document.getElementById('ljModeSwitch');
  var sw2=document.getElementById('ljModeSwitch2');
  var ring=document.getElementById('ljRing');
  function setMode(learn){
    viewT.classList.toggle('hidden', learn);
    viewL.classList.toggle('hidden', !learn);
    sw1.classList.toggle('on', learn); sw1.setAttribute('aria-checked', learn);
    sw2.classList.toggle('on', learn); sw2.setAttribute('aria-checked', learn);
    // sidebar active state
    document.querySelectorAll('.lj-nav').forEach(function(n){
      var v=n.getAttribute('data-nav');
      n.classList.toggle('active', learn ? v==='apprentissage' : v==='accueil');
    });
    if(learn){
      document.querySelectorAll('#ljViewLearn .lj-wave').forEach(buildWave);
      // animate mastery ring to 78%
      setTimeout(function(){
        var c=ring.querySelector('.fg');
        c.style.strokeDashoffset = (170*(1-0.78)).toFixed(1);
      },80);
    } else {
      ring.querySelector('.fg').style.strokeDashoffset=170;
    }
  }
  sw1.addEventListener('click', function(){ setMode(true); });
  sw2.addEventListener('click', function(){ setMode(false); });
  [sw1,sw2].forEach(function(s){ s.addEventListener('keydown',function(e){ if(e.key==='Enter'||e.key===' '){e.preventDefault(); setMode(s===sw1);} }); });

  /* ---- sidebar nav ---- */
  document.querySelectorAll('.lj-nav').forEach(function(n){
    n.addEventListener('click', function(){
      var view=n.getAttribute('data-view');
      if(view==='learn'){ setMode(true); return; }
      if(view==='translate'){ setMode(false); }
      document.querySelectorAll('.lj-nav').forEach(function(x){x.classList.remove('active');});
      n.classList.add('active');
    });
  });

  /* ---- learning tabs ---- */
  document.querySelectorAll('#ljViewLearn .lj-tabs .lj-tab, #ljViewTranslate .lj-tabs .lj-tab').forEach(function(t){
    t.addEventListener('click', function(){
      var sibs=t.parentElement.querySelectorAll('.lj-tab');
      sibs.forEach(function(s){s.classList.remove('active');});
      t.classList.add('active');
    });
  });

  /* ---- voice command demo ---- */
  var voice=document.getElementById('ljVoice');
  var vTitle=document.getElementById('ljVoiceTitle');
  var vSub=document.getElementById('ljVoiceSub');
  voice.addEventListener('click', function(){
    if(voice.classList.contains('listening')) return;
    voice.classList.add('listening');
    vTitle.textContent='\u00c9coute en cours\u2026';
    vSub.textContent='Parlez maintenant';
    setTimeout(function(){
      vTitle.textContent='\u00ab Lis l\u2019original \u00bb';
      vSub.textContent='Commande reconnue \u2713';
      // trigger original audio
      var b=document.querySelector('[data-audio="orig"]'); if(b) b.click();
      setTimeout(function(){
        voice.classList.remove('listening');
        vTitle.textContent='Commande vocale';
        vSub.textContent='\u00ab Lis l\u2019original \u00bb \u00b7 \u00ab R\u00e9p\u00e8te \u00bb \u00b7 \u00ab Explique \u00bb';
      }, 2600);
    }, reduce?200:1800);
  });

  /* ---- scrubber drag (light) ---- */
  var track=document.getElementById('ljTrack');
  if(track){
    var fill=track.querySelector('.fill'), knob=track.querySelector('.knob');
    function moveTo(clientX){
      var r=track.getBoundingClientRect();
      var p=Math.max(0,Math.min(1,(clientX-r.left)/r.width));
      fill.style.width=(p*100)+'%'; knob.style.left=(p*100)+'%';
    }
    track.addEventListener('click', function(e){ moveTo(e.clientX); });
  }
})();
