// Le-J traduit — service worker (Manifest V3) v0.4
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  try { await chrome.sidePanel.open({ tabId: tab.id }); } catch (e) { console.warn("[Le-J] sidePanel.open:", e); }
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
  } catch (e) {
    setTimeout(() => { chrome.runtime.sendMessage({ type: "LJ_STATUS", text: "Cette page n'autorise pas la bulle (page interne du navigateur). La saisie manuelle reste disponible ci-dessous." }).catch(() => {}); }, 400);
  }
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  // capture de la zone visée -> transmise au panneau
  if (msg && msg.type === "LJ_CAPTURE") {
    const tabId = sender && sender.tab ? sender.tab.id : undefined;
    const windowId = sender && sender.tab ? sender.tab.windowId : undefined;
    const done = (dataUrl) => {
      if (chrome.runtime.lastError || !dataUrl) {
        chrome.runtime.sendMessage({ type: "LJ_CAPTURE_ERROR", error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || "capture impossible" }).catch(() => {});
        return;
      }
      chrome.runtime.sendMessage({ type: "LJ_IMAGE", dataUrl, rect: msg.rect, dpr: msg.dpr, tabId }).catch(() => {});
    };
    if (windowId != null) chrome.tabs.captureVisibleTab(windowId, { format: "png" }, done);
    else chrome.tabs.captureVisibleTab({ format: "png" }, done);
    return true;
  }

  // résultat de traduction renvoyé par le panneau -> affiché sur la page près de la bulle
  if (msg && msg.type === "LJ_RESULT") {
    if (msg.tabId != null) {
      chrome.tabs.sendMessage(msg.tabId, { type: "LJ_SHOW_TRANSLATION", original: msg.original, translation: msg.translation, romaji: msg.romaji, tgtLang: msg.tgtLang }).catch(() => {});
    }
    return;
  }

  if (msg && msg.type === "LJ_OPEN_HOME") chrome.tabs.create({ url: chrome.runtime.getURL("home.html") });
});
